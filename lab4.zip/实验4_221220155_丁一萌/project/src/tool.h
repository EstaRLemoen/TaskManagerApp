#ifndef TOOL_H
#define TOOL_H

#include <QWidget>
#include <QMainWindow>
#include <QLabel>
#include <QTextEdit>

class Tool:public QWidget{
    Q_OBJECT
public:
    Tool();
protected:
    QLabel* botton;
};

class AdderInputWidget: public QMainWindow{
    Q_OBJECT
private:
    std::vector<QTextEdit*> input_lines;
signals:
    void sendNewTaskMsg(std::vector<QString*> bItemDescrips);
public:
    AdderInputWidget();
public slots:
    void switchVisibility();
    void save();
    void cancel();
};

class Adder:public Tool{
    Q_OBJECT
private:
    AdderInputWidget* input_widget;
signals:
    void sendNewTaskMsg(std::vector<QString*> bItemDescrips);
public:
    Adder();
public slots:
    void switchVisibility();
    void getNewTaskMsg(std::vector<QString*> bItemDescrips);
protected:
    void mouseDoubleClickEvent(QMouseEvent *event);
    //TODO: reload the hide to hide its `input_widget`
};

class Deleter:public Tool{
    Q_OBJECT
public:
    Deleter();
    //TODO: Finish Deleter
};

class TemplateEditer:public Tool{
    Q_OBJECT
public:
    TemplateEditer();
};

//TODO: class Searcher:public Tool


#endif // TOOL_H
