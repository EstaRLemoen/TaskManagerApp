#ifndef TASKLIST_H
#define TASKLIST_H

#include<QWidget>
#include "taskunit.h"

class TaskList:public QWidget{
    Q_OBJECT
private:
    int list_height;
    int list_width;
    std::vector<TaskUnit*> tasks;
    int getVaildId();
    const ItemModel* getModel(const QString& model_name);
public:
    TaskList(int w,int h,QWidget *parent = nullptr);
    void switchVisibility();
    void addTask(std::vector<ItemUnit*> items);
    void delTask(int task_id);
public slots:
    void getNewTaskMsg(std::vector<QString*> bItemDescrips);
};

#endif // TASKLIST_H
