#include "constant.h"
#include "tasklist.h"
#include "itemunit.h"

TaskList::TaskList(int w,int h,QWidget* parent){
    this->setParent(parent);
    list_width=w;
    list_height=h;
    setWindowFlags(Qt::Tool | Qt::FramelessWindowHint);
    hide();
}

void TaskList::switchVisibility(){
    if(isVisible())
        hide();
    else
        show();
}

void TaskList::addTask(std::vector<ItemUnit*> items){
    TaskUnit* new_task = new TaskUnit(items);
    new_task->setOrderInList(this->tasks.size());
    new_task->setId(this->getVaildId());
    this->tasks.push_back(new_task);
}

void TaskList::delTask(int task_id){
    for (std::vector<TaskUnit*>::iterator it = tasks.begin(); it != tasks.end(); it++) {
        if ((*it)->getId() == task_id) {
            tasks.erase(it);
            return;
        }
    }
    qCritical("DO NOT EXIST a task with the id to delete. ");
}

int TaskList::getVaildId(){
    //TODO: remove old lines below, finish correctly.
    static int seed = -1;
    seed++;
    int new_id;
    new_id = seed;
    return new_id;
}

const ItemModel* TaskList::getModel(const QString& model_name){
    // TODO
    return NULL;
}

void TaskList::getNewTaskMsg(std::vector<QString*> bItemDescrips){
    //TODO: assert about vector length etc.
    std::vector<ItemUnit*> items;
    ItemUnit* item = NULL;
    item->setDescription("gugu");// lab4-3: insert Diagnostics
    for(int i = 0; i < BASIC_ITEM_LIST_LENGTH;i++){
        item = new ItemUnit(this->getModel(BASIC_ITEM_NAME[i]), *(bItemDescrips[i]));
        items.push_back(item);
        item = NULL;
    }
    item->setDescription("gugu");// lab4-4: insert Diagnostics
    addTask(items);
}


