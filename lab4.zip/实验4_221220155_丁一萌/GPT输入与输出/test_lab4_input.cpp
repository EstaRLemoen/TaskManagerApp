#include <iostream>
#include <cstring>
#include <vector>
#include <string>
#include <cstdlib>
#include <fstream>
#include <ctime>
#include <cmath>

using namespace std;

void example20() {
    ifstream file("a.txt");
    file.close();
    cout << "File closed successfully" << endl;
}

void example1(const string& userInput) {
    string command = "ls " + userInput;
    system(command.c_str());
}

void example2() {
    ifstream file("a.txt");
    file.read(nullptr, 10);
}

void example3() {
    char buffer[10]; 
    cout << "Buffer content: " << buffer << endl;
}

void example4() {
    char buf[10];
    gets(buf); 
    cout << "User input: " << buf << endl;
}

void example5(const char* userInput) {
    char buffer[10];
    strncpy(buffer, userInput, strlen(userInput)); 
    cout << "Buffer: " << buffer << endl;
}

void example6(const string& userInput) {
    string xml = "<user><name>" + userInput + "</name></user>";
    cout << "XML content: " << xml << endl; 
}

void example7() {
    FILE* file = fopen("a.txt", "w");
    if (!file) return;
    // File not closed
}

void example8(const string& userCode) {
    void (*func)();
    func = (void (*)())userCode.c_str();
    func();
}

void example9(int* ptr) {
    if (ptr && *ptr > 0) {
        cout << "Pointer value: " << *ptr << endl;
    } else if (ptr == nullptr) {
        cout << "Null pointer accessed" << endl;
    } 
}

void example10() {
    char buffer[10];
    strcpy(buffer, "This is a                  string");
    cout << buffer << endl;
}

void example11(string userInput) {
    string query = "SELECT * FROM users WHERE name = '" + userInput + "';";
    cout << "Executing query: " << query << endl; 
}

void example12() {
    int* ptr = nullptr;
    *ptr = 42; 
}

void example13() {
    int m = INT_MAX;
    m += 1; 
    cout << "the new value: " << m << endl;
}

void example14() {
    int* data = new int(42);
    delete data;
    cout << *data << endl; 
}

void example15() {
    int* data = new int[100];
}

void example16(const char* userInput) {
    printf("%s\n",userInput);
}


void example17() {
    int x;
    cout << "value: " << x << endl;
}

void example18() {
    system("chmod 777 /etc/passwd");
}

void example19() {
    int ptr;
    ptr = 10;
}

int test_main() {
    // Call each example
    example1("test; rm -rf /");
    example2();
    example3();
    example4();
    example5("This     input      is      for    the      buffer");
    example6("<script>alert('attack')</script>");
    example7();
    example8("testing__ code");
    int* null_ptr = nullptr;
    example9(null_ptr);
    example10();
    example11("test' OR '1'='1");
    example12();
    example13();
    example14();
    example15();
    example16("User input %x %x");
    example17();
    example18();
    example19();
    example20();


    return 0;
}
