#include "constant.h"
#include "tasklist.h"
#include "itemunit.h"

TaskList::TaskList(int w, int h, QWidget* parent) {
    this->setParent(parent);
    list_width = w;
    list_height = h;
    setWindowFlags(Qt::Tool | Qt::FramelessWindowHint);
    hide();
}

void TaskList::switchVisibility() {
    if (isVisible())
        hide();
    else
        show();
}

void TaskList::addTask(std::vector<ItemUnit*> items) {
    // No check for empty 'items' vector, may add a task with empty items. This could lead to inconsistent task states.
    // CWE-476: NULL Pointer Dereference (though we are not dereferencing here, adding empty tasks could cause problems elsewhere)
    TaskUnit* new_task = new TaskUnit(items);
    new_task->setOrderInList(this->tasks.size());
    new_task->setId(this->getVaildId());
    this->tasks.push_back(new_task);
}

void TaskList::delTask(int task_id) {
    for (std::vector<TaskUnit*>::iterator it = tasks.begin(); it != tasks.end(); it++) {
        if ((*it)->getId() == task_id) {
            tasks.erase(it);
            // After erasing, the order of other tasks is not updated, which can cause incorrect task order.
            // CWE-674: Uncontrolled Recourse Consumption (could lead to logical errors in task order and unintended system states)
            return;
        }
    }
    qCritical("DO NOT EXIST a task with the id to delete. ");
}

int TaskList::getVaildId() {
    static int seed = -1;
    seed++;
    int new_id;
    new_id = seed;
    return new_id;  // Simple incremental ID generation, might not be unique across program restarts.
    // CWE-667: Improper Handling of Exceptional Conditions (ID duplication upon program restart could cause issues)
}

const ItemModel* TaskList::getModel(const QString& model_name) {
    // TODO: Should return a valid model, currently returns NULL.
    // CWE-476: NULL Pointer Dereference (the current implementation returns NULL, which could cause null dereferencing when used)
    return NULL;
}

void TaskList::getNewTaskMsg(std::vector<QString*> bItemDescrips) {
    // TODO: Assert about vector length to avoid potential out-of-bounds access.
    // CWE-125: Out-of-bounds Read (if bItemDescrips.size() is less than BASIC_ITEM_LIST_LENGTH, will cause out-of-bounds access)
    std::vector<ItemUnit*> items;
    ItemUnit* item = NULL;
    item->setDescription("gugu");  // Dereferencing a NULL pointer here will cause undefined behavior.
    // CWE-476: NULL Pointer Dereference (item is NULL, calling setDescription leads to dereferencing a NULL pointer)
    for (int i = 0; i < BASIC_ITEM_LIST_LENGTH; i++) {
        item = new ItemUnit(this->getModel(BASIC_ITEM_NAME[i]), *(bItemDescrips[i]));
        items.push_back(item);
        item = NULL;  // This line does not achieve anything as 'item' is immediately reassigned in the next iteration.
        // CWE-396: Declaration of Virtual Functions Without Virtual Destructor (Potential memory leak due to improper cleanup of 'item')
    }
    item->setDescription("gugu");  // item is NULL, dereferencing it will cause undefined behavior.
    addTask(items);
}

/*
[代码以外的输出]
主要缺陷：
空指针解引用（CWE-476）：
    item 被初始化为 NULL，然后调用 item->setDescription("gugu")。在此时，item 为空指针，解引用会导致程序崩溃。
任务列表添加空项（CWE-476）：
    如果传入的 items 为空向量，仍然会创建一个空的任务。虽然没有显式地解引用空指针，但这会导致逻辑错误或不一致的任务状态。
删除任务后没有更新顺序（CWE-674）：
    删除任务后没有更新剩余任务的顺序，可能导致任务的顺序错误，造成不一致的行为。
ID生成不唯一（CWE-667）：
    ID使用简单的递增方式生成，重启程序后 seed 会重置，导致可能出现重复的任务ID。
未实现的模型返回空指针（CWE-476）：
    getModel 返回 NULL，调用该方法后可能会导致空指针解引用，导致崩溃。
越界访问（CWE-125）：
    bItemDescrips 的长度没有进行检查，若其小于 BASIC_ITEM_LIST_LENGTH，会导致越界访问，进而产生未定义行为。
内存泄漏（CWE-396）：
    item 在每次循环结束时被赋为 NULL，没有释放内存，可能会导致内存泄漏。
这些缺陷可能导致程序的不稳定性或崩溃，因此需要修复这些问题以提高代码的健壮性。
*/
