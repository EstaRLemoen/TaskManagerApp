#include <iostream>
#include <cstring>
#include <vector>
#include <string>
#include <cstdlib>
#include <fstream>
#include <ctime>
#include <cmath>

using namespace std;

void example20() {
    ifstream file("a.txt");
    file.close();
    cout << "File closed successfully" << endl;
}

void example1(const string& userInput) {
    // CWE-78: Improper Neutralization of Special Elements used in an OS Command ('OS Command Injection')
    string command = "ls " + userInput;
    system(command.c_str());
}

void example2() {
    // CWE-119: Improper Restriction of Operations within the Bounds of a Memory Buffer
    ifstream file("a.txt");
    file.read(nullptr, 10);  // Passing nullptr as the buffer is unsafe
}

void example3() {
    // CWE-121: Stack-based Buffer Overflow
    char buffer[10]; 
    cout << "Buffer content: " << buffer << endl;  // Uninitialized buffer, potential undefined behavior
}

void example4() {
    // CWE-121: Stack-based Buffer Overflow
    char buf[10];
    gets(buf);  // CWE-767: Access to Critical Private Variable via 'gets()'
    cout << "User input: " << buf << endl;  // Vulnerability due to buffer overflow
}

void example5(const char* userInput) {
    // CWE-121: Stack-based Buffer Overflow
    char buffer[10];
    strncpy(buffer, userInput, strlen(userInput));  // No null-termination check
    cout << "Buffer: " << buffer << endl;
}

void example6(const string& userInput) {
    // CWE-20: Improper Input Validation
    string xml = "<user><name>" + userInput + "</name></user>";
    cout << "XML content: " << xml << endl;  // User input could break the XML structure
}

void example7() {
    // CWE-404: Improper Resource Shutdown or Release
    FILE* file = fopen("a.txt", "w");
    if (!file) return;
    // File not closed properly
}

void example8(const string& userCode) {
    // CWE-94: Improper Control of Generation of Code ('Code Injection')
    void (*func)();
    func = (void (*)())userCode.c_str();
    func();  // Dangerous code execution via user input
}

void example9(int* ptr) {
    if (ptr && *ptr > 0) {
        cout << "Pointer value: " << *ptr << endl;
    } else if (ptr == nullptr) {
        cout << "Null pointer accessed" << endl;  // CWE-476: NULL Pointer Dereference
    } 
}

void example10() {
    // CWE-121: Stack-based Buffer Overflow
    char buffer[10];
    strcpy(buffer, "This is a                  string");  // Buffer overflow, no bounds check
    cout << buffer << endl;
}

void example11(string userInput) {
    // CWE-89: Improper Neutralization of Special Elements used in an SQL Command ('SQL Injection')
    string query = "SELECT * FROM users WHERE name = '" + userInput + "';";
    cout << "Executing query: " << query << endl;  // SQL Injection vulnerability
}

void example12() {
    // CWE-476: NULL Pointer Dereference
    int* ptr = nullptr;
    *ptr = 42;  // Dereferencing a null pointer
}

void example13() {
    // CWE-190: Integer Overflow or Wraparound
    int m = INT_MAX;
    m += 1;  // Integer overflow
    cout << "the new value: " << m << endl;
}

void example14() {
    // CWE-416: Use After Free
    int* data = new int(42);
    delete data;
    cout << *data << endl;  // Accessing freed memory
}

void example15() {
    // CWE-415: Double Free
    int* data = new int[100];
    // Potential double-free issue if delete is called elsewhere
}

void example16(const char* userInput) {
    // CWE-134: Use of Externally-Controlled Format String
    printf("%s\n", userInput);  // User-controlled input could exploit format string vulnerabilities
}

void example17() {
    // CWE-561: Dead Code
    int x;
    cout << "value: " << x << endl;  // Uninitialized variable access (undefined behavior)
}

void example18() {
    // CWE-78: Improper Neutralization of Special Elements used in an OS Command ('OS Command Injection')
    system("chmod 777 /etc/passwd");  // Dangerous system call that could be exploited
}

void example19() {
    // CWE-476: NULL Pointer Dereference
    int ptr;
    ptr = 10;
    // Confusing naming: ptr is not a pointer, but the variable is named as if it is
}

int test_main() {
    // Call each example
    example1("test; rm -rf /");  // Command injection
    example2();
    example3();
    example4();
    example5("This     input      is      for    the      buffer");
    example6("<script>alert('attack')</script>");
    example7();
    example8("testing__ code");
    int* null_ptr = nullptr;
    example9(null_ptr);
    example10();
    example11("test' OR '1'='1");
    example12();
    example13();
    example14();
    example15();
    example16("User input %x %x");
    example17();
    example18();
    example19();
    example20();

    return 0;
}
