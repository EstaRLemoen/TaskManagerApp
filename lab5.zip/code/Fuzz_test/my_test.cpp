#include <iostream>
#include <string>
using namespace std;

// ITEMTYPE INFO
const int ITEMTYPE_NUMBER = 3;
const string ITEMTYPE_LIST[ITEMTYPE_NUMBER] = {
    "number",
    "string",
    "timestamp"
};
enum class ITEMTYPE_INDEX{
    NUM = 0,
    STR = 1,
    TIME = 2
};

bool checkDescripWithType(const string& descrip, const string& type){
    cout << "descrip:" << descrip << endl;
    cout << "itemtype:" << type<< endl;
    if(type == ITEMTYPE_LIST[(int)ITEMTYPE_INDEX::STR]){
        return true;
    }
    else if(type == ITEMTYPE_LIST[(int)ITEMTYPE_INDEX::NUM]){
        return true;
    }
    else if(type == ITEMTYPE_LIST[(int)ITEMTYPE_INDEX::TIME]){
        return true;
    }
    else{
        cout << "type with this index do not exist!!!!!!" << endl;
        return false;
    }
}

int main(){
    string name;
    string type;
    cin >> name;
    cin >> type;
    cout << checkDescripWithType(name,type);
    return 0;
}