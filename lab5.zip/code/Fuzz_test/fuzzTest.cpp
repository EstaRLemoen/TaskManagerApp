//docker run -it --name afl --ipc=host  -v  "C:\myGithub\SE_lab\Fuzz_test":/AFLplusplus/my_test aflplusplus/aflplusplus

#include <iostream>
using namespace std;

int main()
{
    char buf[100] = {0};
    scanf("%s", buf);   //存在栈溢出漏洞
    printf("%s", buf); //存在格式化字符串漏洞
    return 0;
}

//afl-clang-fast++ -g -o fuzzTest fuzzTest.cpp
//afl-fuzz -i fuzz_in -o fuzz_out ./fuzzTest
